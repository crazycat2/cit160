function myMove() {
  var elem = document.getElementById("animate");   
  var pos = 0;
  var id = setInterval(frame, 5);
function frame() {
    if (pos == 190) {
      clearInterval(id);
    } else {
      pos++;  
      elem.style.left = pos + 'px'; 
    }
  }
}

function myMove2() {
  var elem = document.getElementById("animate");   
  var pos = 190;
  var id = setInterval(frame, 5);
function frame() {
    if (pos == 0) {
      clearInterval(id);
    } else {
      pos--;  
      elem.style.left = pos + 'px'; 
    }
  }
}




function mOver(obj) {
  obj.innerHTML = " <h2> click stuff ... at your own risk </h2> "; }
function mOut(obj) {
  obj.innerHTML = " <h2> seriously though click away ;) </h2>";}


function changeText(id) {
  id.innerHTML = " <h2> I am sooo smart..jk </h2>";}


function myMove3() {
  var elem = document.getElementById("pancake2");   
  var pos = 0;
  var id = setInterval(frame, 5);
  function frame() {
    if (pos == 350) {
      clearInterval(id);
    } else {
      pos++; 
      elem.style.top = pos + 'px'; 
     
    }
  }
}

function meh(){
var animals = ["mountain lion","deer", "snake", "mouse", "insects","plants"];
document.getElementById("syrup").innerHTML = animals;
}

function meh2(){
var animals = ["mountain lion","deer", "snake", "mouse", "insects","plants"];
delete animals[0];
document.getElementById("syrup").innerHTML = animals + "<br>Then they all die</br>";
}
